# -*- coding: utf-8 -*-
from distutils.core import setup
import py2exe
import sys,os
if sys.version_info.major >= 3.0:
    opt_bundle_files = 0
else:
    opt_bundle_files = 1
includes = ["PyQt4.QtCore","PyQt4.QtGui","sip"]
options = {"py2exe":{ "compressed": 1,"optimize": 2,"includes": includes,"bundle_files": opt_bundle_files,}}
dll_excludes = ['libgdk-win32-2.0-0.dll', 'libgobject-2.0-0.dll','tcl84.dll', 'tk84.dll', 'POWRPROF.dll']
setup(version = "1.0",description = "test_add",options = { "py2exe":{"dll_excludes":["MSVCP90.dll"]}},zipfile=None,console=[{"script": "Game.py" }],windows=[{"script": "Game.py" }],)
