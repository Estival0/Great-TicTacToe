# -*- coding: cp936 -*-
# Great TicTacToe
# ������
# ������
# �� ͯ

import random, pygame, sys
from pygame.locals import *
from random import *
import os

#����ߴ�
FPS = 30
WINDOWWIDTH = 800
WINDOWHEIGHT = 600
HALFWINDOWWIDTH = WINDOWWIDTH/2
HALFWINDOWHEIGHT = WINDOWHEIGHT/2
BOXLENGTH = 50
BOXSMALLGAP = 5
BOXBIGGAP = 10
XMARGIN = 150
YMARGIN = 50
BOARD = 3

#�����ֵ��ȷ
#assert

#��ɫ����     R    G    B
GRAY     = (100, 100, 100)
NAVYBLUE = ( 60,  60, 100)
WHITE    = (255, 255, 255)
RED      = (255,   0,   0)
GREEN    = (  0, 255,   0)
BLUE     = (  0,   0, 255)
YELLOW   = (255, 255,   0)
ORANGE   = (255, 128,   0)
PURPLE   = (255,   0, 255)
CYAN     = (  0, 255, 255)

#����

#������ɫѡȡ
BGCOLOR = GREEN

#��ʼ81������
EIGHTYONE=[[[[None,None,None],[None,None,None],[None,None,None]],[[None,None,None],[None,None,None],[None,None,None]],[[None,None,None],[None,None,None],[None,None,None]]],
           [[[None,None,None],[None,None,None],[None,None,None]],[[None,None,None],[None,None,None],[None,None,None]],[[None,None,None],[None,None,None],[None,None,None]]],
           [[[None,None,None],[None,None,None],[None,None,None]],[[None,None,None],[None,None,None],[None,None,None]],[[None,None,None],[None,None,None],[None,None,None]]]]
#��ʼ9������
NINE=[[None,None,None],[None,None,None],[None,None,None]]
#��ʼ��Ϸ��ʤ���
RESULT=0





#������
def main():
    #����ȫ�ֱ���
    global FPSCLOCK, DISPLAYSURF, IMAGESDICT, BASICFONT, boxAx, boxAy, mousex, mousey, RESULT
    
    pygame.init()
    FPSCLOCK = pygame.time.Clock()#ѭ��ʱ��
    DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))#�ߴ�




    pygame.display.set_caption('Great TicTacToe')#����
    BASICFONT = pygame.font.SysFont('arial',20)#����


    IMAGESDICT = {'rubbish1': pygame.image.load('rubbish1.jpg'),
                  'rubbish2': pygame.image.load('rubbish2.jpg'),
                  'plant1': pygame.image.load('plant1.jpg'),
                  'plant2': pygame.image.load('plant2.jpg'),
                  'guize':pygame.image.load('guize.jpg'),
                  'beijing':pygame.image.load('beijing.jpg'),
                  'huosheng':pygame.image.load('huosheng.jpg')}
    
    DISPLAYSURF.fill(BGCOLOR)#�������
    DISPLAYSURF.blit(IMAGESDICT['guize'],(0,0))

    textSurf = BASICFONT.render('Press muosebutton to start! Don\'t click outside the white box.', True, RED, NAVYBLUE)
    textRect = textSurf.get_rect()
    textRect.center=(400,580)#λ�ô�
    DISPLAYSURF.blit(textSurf,textRect)
    
    pygame.display.update()
    mouseClicked = False
    while True:
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYUP
                                      and event.key == K_ESCAPE):#���������
                    pygame.quit()
                    sys.exit()
            #elif event.type == MOUSEMOTION:
                    #mousex, mousey = event.pos
            elif event.type == MOUSEBUTTONDOWN:
                    mousex, mousey = event.pos
                    mouseClicked = True

        if mouseClicked == True:
            break
        else:
            continue
    
    
    
    #�ڶ��ֻ���
    #drawBoxA()
    #drawBoxB()


    #����81������
    DISPLAYSURF.blit(IMAGESDICT['beijing'],(0,0))
    DRAW81SQUARES()
    mousex = 0
    mousey = 0
    pygame.display.update()


    #mainBoard = getRandomizedBoard()#��ʼ���ݽṹ
    #revealedBoxes = generateRevealedBoxesData(False)

    firstSelection = None#��ʼ����ʼ��ѡ״̬
    
    
    #startGameAnimation(mainBoard)#��ʼ����

    #��һ����������
    mouseClicked = False
    while True:
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYUP
                                      and event.key == K_ESCAPE):#���������
                    pygame.quit()
                    sys.exit()
            #elif event.type == MOUSEMOTION:
                    #mousex, mousey = event.pos
            elif event.type == MOUSEBUTTONDOWN:
                    mousex, mousey = event.pos
                    mouseClicked = True

        if mouseClicked == True and getBoxAtPixelA(mousex, mousey) != (None,None):
            boxAx, boxAy = getBoxAtPixelA(mousex, mousey)#���9*9�������
            boxBx, boxBy = getBoxAtPixelB(mousex, mousey)#���3*3С������        
            EIGHTYONE[boxAx][boxAy][boxBx][boxBy] = 'belongtoA'#��ֵ��1*1
            darwimag(boxAx,boxAy,boxBx,boxBy)
            pygame.display.update()
            break
        else:
            continue
    

    

    #��Ϸѭ������
    while mouseClicked == True:
        #DISPLAYSURF.fill(BGCOLOR)#��仭��
        #drawBoard(mainBoard, revealedBoxes)
        
        #��ʱ
        pygame.time.wait(1500)

        if NINE[boxBx][boxBy] == None:

            #��������λ��
            randombox=[]
            randomnumber=0
            for i in [0,1,2]:
                for j in [0,1,2]:
                    if EIGHTYONE[boxBx][boxBy][i][j] == None:#����û���¹��ĸ���
                        randombox.append([i,j])
            randomnumber = randint(1,len(randombox))-1
            positionx,positiony = randombox[randomnumber]#���һ����������λ��

            boxAx=boxBx
            boxAy=boxBy
            boxBx=positionx
            boxBy=positiony
            #print boxAx,boxAy,boxBx,boxBy
            EIGHTYONE[boxAx][boxAy][boxBx][boxBy] = 'belongtoB'

        else:
            randombox=[]
            randomnumber=0
            for i in [0,1,2]:
                for j in [0,1,2]:
                    for m in [0,1,2]:
                        for n in [0,1,2]:
                            if EIGHTYONE[i][j][m][n] == None:#����û���¹��ĸ���
                                randombox.append([i,j,m,n])
            randomnumber = randint(1,len(randombox))-1
            positionAx,positionAy,positionBx,positionBy = randombox[randomnumber]#���һ����������λ��

            boxAx=positionAx
            boxAy=positionAy
            boxBx=positionBx
            boxBy=positionBy
            #print boxAx,boxAy,boxBx,boxBy
            EIGHTYONE[boxAx][boxAy][boxBx][boxBy] = 'belongtoB'
        
        

        #ˢͼ
        darwimag(boxAx,boxAy,boxBx,boxBy)
        pygame.display.update()

        #�ж��Ƿ��л�ʤ
        NINE[boxAx][boxAy]=SMALLBOX(boxAx,boxAy)
        print SMALLBOX(boxAx,boxAy)
        if SMALLBOX(boxAx,boxAy) != None:
            pygame.time.wait(1500)
            for i in range(BOARD):
                for j in range(BOARD):
                    EIGHTYONE[boxAx][boxAy][i][j]=SMALLBOX(boxAx,boxAy)
                    darwimag(boxAx,boxAy,i,j)
                    pygame.display.update()
                    
            RESULT=BIGBOX()
            #print NINE
            if RESULT != None:
                showresult()
                break


        mouseClicked = False#����ʼ

        
        #�¼�����ѭ��
        while mouseClicked == False:
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYUP
                                      and event.key == K_ESCAPE):#���������
                    pygame.quit()
                    sys.exit()
                #elif event.type == MOUSEMOTION:
                    #mousex, mousey = event.pos
                elif event.type == MOUSEBUTTONDOWN:
                    mousex, mousey = event.pos
                    mouseClicked = True

            if mouseClicked == True:
                #if NINE[boxBx][boxBy] != None:
                    

                
                boxAx, boxAy = getBoxAtPixelA(mousex, mousey)
                boxBx, boxBy = getBoxAtPixelB(mousex, mousey)
                #if (boxAx == positionx and boxAy == positiony):#�Ƿ��ڿ����µ�3*3��
                if EIGHTYONE[boxAx][boxAy][boxBx][boxBy] == None:#�Ƿ��ڿ����µĸ�����
                        EIGHTYONE[boxAx][boxAy][boxBx][boxBy] = 'belongtoA'
                        
                        #ˢͼ
                        darwimag(boxAx,boxAy,boxBx,boxBy)
                        pygame.display.update()
                    
                    #�ж��Ƿ��л�ʤ
                        NINE[boxAx][boxAy]=SMALLBOX(boxAx,boxAy)
                        #print SMALLBOX(boxAx,boxAy)
                        if SMALLBOX(boxAx,boxAy) != None:
                            pygame.time.wait(1500)
                            for i in range(BOARD):
                                for j in range(BOARD):
                                    EIGHTYONE[boxAx][boxAy][i][j]=SMALLBOX(boxAx,boxAy)
                                    darwimag(boxAx,boxAy,i,j)
                                    pygame.display.update()
                    
                            RESULT=BIGBOX()
                            #print NINE
                            if RESULT != None:
                                showresult()
                                break
            else:
                continue

    

            

             
            


                    
        pygame.display.update()#����
        FPSCLOCK.tick(FPS)
        
    #��ʤ����
    pygame.display.update()#����
    FPSCLOCK.tick(FPS)





def DRAW81SQUARES():
    for n in [0,1,2]:
        for m in [0,1,2]:
            for i in [0,1,2]:
                for j in [0,1,2]:
                    pygame.draw.polygon(DISPLAYSURF, WHITE,
                                        ((150+(BOXLENGTH+BOXSMALLGAP)*i+(3*BOXLENGTH+2*BOXSMALLGAP+BOXBIGGAP)*m,50+(BOXLENGTH+BOXSMALLGAP)*j+(3*BOXLENGTH+2*BOXSMALLGAP+BOXBIGGAP)*n),
                                         (200+(BOXLENGTH+BOXSMALLGAP)*i+(3*BOXLENGTH+2*BOXSMALLGAP+BOXBIGGAP)*m,50+(BOXLENGTH+BOXSMALLGAP)*j+(3*BOXLENGTH+2*BOXSMALLGAP+BOXBIGGAP)*n),
                                         (200+(BOXLENGTH+BOXSMALLGAP)*i+(3*BOXLENGTH+2*BOXSMALLGAP+BOXBIGGAP)*m,100+(BOXLENGTH+BOXSMALLGAP)*j+(3*BOXLENGTH+2*BOXSMALLGAP+BOXBIGGAP)*n),
                                         (150+(BOXLENGTH+BOXSMALLGAP)*i+(3*BOXLENGTH+2*BOXSMALLGAP+BOXBIGGAP)*m,100+(BOXLENGTH+BOXSMALLGAP)*j+(3*BOXLENGTH+2*BOXSMALLGAP+BOXBIGGAP)*n)))





def SMALLBOX(boxx,boxy):#�������boxAx,boxAy
                        #�ж�3*3��״̬
    smallbox=EIGHTYONE
    if ((smallbox[boxx][boxy][0][0]=='belongtoA' and smallbox[boxx][boxy][0][0]==smallbox[boxx][boxy][0][1] and smallbox[boxx][boxy][0][0]==smallbox[boxx][boxy][0][2]) or
        (smallbox[boxx][boxy][0][0]=='belongtoA' and smallbox[boxx][boxy][0][0]==smallbox[boxx][boxy][1][1] and smallbox[boxx][boxy][0][0]==smallbox[boxx][boxy][2][2]) or
        (smallbox[boxx][boxy][0][0]=='belongtoA' and smallbox[boxx][boxy][0][0]==smallbox[boxx][boxy][1][0] and smallbox[boxx][boxy][0][0]==smallbox[boxx][boxy][2][0]) or
        (smallbox[boxx][boxy][0][1]=='belongtoA' and smallbox[boxx][boxy][0][1]==smallbox[boxx][boxy][1][1] and smallbox[boxx][boxy][0][1]==smallbox[boxx][boxy][2][1]) or
        (smallbox[boxx][boxy][0][2]=='belongtoA' and smallbox[boxx][boxy][0][2]==smallbox[boxx][boxy][1][2] and smallbox[boxx][boxy][0][2]==smallbox[boxx][boxy][2][2]) or
        (smallbox[boxx][boxy][0][2]=='belongtoA' and smallbox[boxx][boxy][0][2]==smallbox[boxx][boxy][1][1] and smallbox[boxx][boxy][0][2]==smallbox[boxx][boxy][2][0]) or
        (smallbox[boxx][boxy][1][0]=='belongtoA' and smallbox[boxx][boxy][1][0]==smallbox[boxx][boxy][1][1] and smallbox[boxx][boxy][1][0]==smallbox[boxx][boxy][1][2]) or
        (smallbox[boxx][boxy][2][0]=='belongtoA' and smallbox[boxx][boxy][2][0]==smallbox[boxx][boxy][2][1] and smallbox[boxx][boxy][1][0]==smallbox[boxx][boxy][2][2])):
            return 'belongtoA'
    
    elif ((smallbox[boxx][boxy][0][0]=='belongtoB' and smallbox[boxx][boxy][0][0]==smallbox[boxx][boxy][0][1] and smallbox[boxx][boxy][0][0]==smallbox[boxx][boxy][0][2]) or
          (smallbox[boxx][boxy][0][0]=='belongtoB' and smallbox[boxx][boxy][0][0]==smallbox[boxx][boxy][1][1] and smallbox[boxx][boxy][0][0]==smallbox[boxx][boxy][2][2]) or
          (smallbox[boxx][boxy][0][0]=='belongtoB' and smallbox[boxx][boxy][0][0]==smallbox[boxx][boxy][1][0] and smallbox[boxx][boxy][0][0]==smallbox[boxx][boxy][2][0]) or
          (smallbox[boxx][boxy][0][1]=='belongtoB' and smallbox[boxx][boxy][0][1]==smallbox[boxx][boxy][1][1] and smallbox[boxx][boxy][0][1]==smallbox[boxx][boxy][2][1]) or
          (smallbox[boxx][boxy][0][2]=='belongtoB' and smallbox[boxx][boxy][0][2]==smallbox[boxx][boxy][1][2] and smallbox[boxx][boxy][0][2]==smallbox[boxx][boxy][2][2]) or
          (smallbox[boxx][boxy][0][2]=='belongtoB' and smallbox[boxx][boxy][0][2]==smallbox[boxx][boxy][1][1] and smallbox[boxx][boxy][0][2]==smallbox[boxx][boxy][2][0]) or
          (smallbox[boxx][boxy][1][0]=='belongtoB' and smallbox[boxx][boxy][1][0]==smallbox[boxx][boxy][1][1] and smallbox[boxx][boxy][1][0]==smallbox[boxx][boxy][1][2]) or
          (smallbox[boxx][boxy][2][0]=='belongtoB' and smallbox[boxx][boxy][2][0]==smallbox[boxx][boxy][2][1] and smallbox[boxx][boxy][1][0]==smallbox[boxx][boxy][2][2])):
            return 'belongtoB'

    elif  (smallbox[boxx][boxy][0][0] != None and smallbox[boxx][boxy][0][1] != None and smallbox[boxx][boxy][0][2] != None and
           smallbox[boxx][boxy][2][0] != None and smallbox[boxx][boxy][1][0] != None and smallbox[boxx][boxy][1][1] != None and
           smallbox[boxx][boxy][1][2] != None and smallbox[boxx][boxy][2][1] != None and smallbox[boxx][boxy][2][2] != None):
            return '55open'
            
    else:
            return None






def BIGBOX():#�ж�9*9��״̬
    smallbox=NINE
    if ((smallbox[0][0] == 'belongtoA' and smallbox[0][0]==smallbox[0][1] and smallbox[0][0]==smallbox[0][2]) or
        (smallbox[0][0] == 'belongtoA' and smallbox[0][0]==smallbox[1][1] and smallbox[0][0]==smallbox[2][2]) or
        (smallbox[0][0] == 'belongtoA' and smallbox[0][0]==smallbox[1][0] and smallbox[0][0]==smallbox[2][0]) or
        (smallbox[1][0] == 'belongtoA' and smallbox[1][0]==smallbox[1][1] and smallbox[1][0]==smallbox[1][2]) or
        (smallbox[2][0] == 'belongtoA' and smallbox[2][0]==smallbox[2][1] and smallbox[2][0]==smallbox[2][2]) or
        (smallbox[2][0] == 'belongtoA' and smallbox[2][0]==smallbox[1][1] and smallbox[2][0]==smallbox[0][2]) or
        (smallbox[0][1] == 'belongtoA' and smallbox[0][1]==smallbox[1][1] and smallbox[0][1]==smallbox[2][1]) or
        (smallbox[0][2] == 'belongtoA' and smallbox[0][2]==smallbox[1][2] and smallbox[0][2]==smallbox[2][2])):
            return 'Awin'

    elif ((smallbox[0][0] == 'belongtoB' and smallbox[0][0]==smallbox[0][1] and smallbox[0][0]==smallbox[0][2]) or
        (smallbox[0][0] == 'belongtoB' and smallbox[0][0]==smallbox[1][1] and smallbox[0][0]==smallbox[2][2]) or
        (smallbox[0][0] == 'belongtoB' and smallbox[0][0]==smallbox[1][0] and smallbox[0][0]==smallbox[2][0]) or
        (smallbox[1][0] == 'belongtoB' and smallbox[1][0]==smallbox[1][1] and smallbox[1][0]==smallbox[1][2]) or
        (smallbox[2][0] == 'belongtoB' and smallbox[2][0]==smallbox[2][1] and smallbox[2][0]==smallbox[2][2]) or
        (smallbox[2][0] == 'belongtoB' and smallbox[2][0]==smallbox[1][1] and smallbox[2][0]==smallbox[0][2]) or
        (smallbox[0][1] == 'belongtoB' and smallbox[0][1]==smallbox[1][1] and smallbox[0][1]==smallbox[2][1]) or
        (smallbox[0][2] == 'belongtoB' and smallbox[0][2]==smallbox[1][2] and smallbox[0][2]==smallbox[2][2])):
            return 'Bwin'

    elif (smallbox[0][0] != None and smallbox[0][1] != None and smallbox[0][2] != None
          and smallbox[1][0] != None and smallbox[1][1] != None and smallbox[1][2] != None and smallbox[2][0] != None and smallbox[2][1] != None and smallbox[2][2] != None):
            return 'DRAW GAME'

    else:
            return None





def leftTopCoordsOfBoxA(boxx, boxy):
    # Convert board coordinates to pixel coordinates
    left = boxx * (BOXLENGTH*3+2*BOXSMALLGAP + BOXBIGGAP) + XMARGIN
    top = boxy * (BOXLENGTH*3+2*BOXSMALLGAP + BOXBIGGAP) + YMARGIN
    return (left, top)





def leftTopCoordsOfBoxB(x, y):
    # Convert board coordinates to pixel coordinates
    if boxAx==0:
        if boxAy==0:
            leftB = x * (BOXLENGTH + BOXSMALLGAP) + XMARGIN
            topB = y * (BOXLENGTH + BOXSMALLGAP) + YMARGIN
            return (leftB,topB)
        elif boxAy==1:
            leftB = x * (BOXLENGTH + BOXSMALLGAP) + XMARGIN
            topB = y * (BOXLENGTH + BOXSMALLGAP) + YMARGIN + BOXBIGGAP + (BOXLENGTH*3+2*BOXSMALLGAP)
            return (leftB,topB)
        elif boxAy==2:
            leftB = x * (BOXLENGTH + BOXSMALLGAP) + XMARGIN
            topB = y * (BOXLENGTH + BOXSMALLGAP) + YMARGIN + BOXBIGGAP*2 +(BOXLENGTH*3+2*BOXSMALLGAP) *2
            return (leftB,topB)
    elif boxAx==1:
        if boxAy==0:
            leftB = x * (BOXLENGTH + BOXSMALLGAP) + XMARGIN + BOXBIGGAP + (BOXLENGTH*3+2*BOXSMALLGAP)
            topB = y * (BOXLENGTH + BOXSMALLGAP) + YMARGIN
            return (leftB,topB)
        elif boxAy==1:
            leftB = x * (BOXLENGTH + BOXSMALLGAP) + XMARGIN + BOXBIGGAP+ (BOXLENGTH*3+2*BOXSMALLGAP)
            topB = y * (BOXLENGTH + BOXSMALLGAP) + YMARGIN + BOXBIGGAP + (BOXLENGTH*3+2*BOXSMALLGAP)
            return (leftB,topB)
        elif boxAy==2:
            leftB = x * (BOXLENGTH + BOXSMALLGAP) + XMARGIN + BOXBIGGAP+ (BOXLENGTH*3+2*BOXSMALLGAP)
            topB = y * (BOXLENGTH + BOXSMALLGAP) + YMARGIN + BOXBIGGAP*2  + (BOXLENGTH*3+2*BOXSMALLGAP)*2
            return (leftB,topB)
    elif boxAx==2:
        if boxAy==0:
            leftB = x * (BOXLENGTH + BOXSMALLGAP) + XMARGIN + BOXBIGGAP*2 + (BOXLENGTH*3+2*BOXSMALLGAP)*2
            topB = y * (BOXLENGTH + BOXSMALLGAP) + YMARGIN
            return (leftB,topB)
        elif boxAy==1:
            leftB = x * (BOXLENGTH + BOXSMALLGAP) + XMARGIN + BOXBIGGAP*2 + (BOXLENGTH*3+2*BOXSMALLGAP)*2
            topB = y * (BOXLENGTH + BOXSMALLGAP) + YMARGIN + BOXBIGGAP  + (BOXLENGTH*3+2*BOXSMALLGAP)
            return (leftB,topB)
        elif boxAy==2:
            leftB = x * (BOXLENGTH + BOXSMALLGAP) + XMARGIN + BOXBIGGAP*2 + (BOXLENGTH*3+2*BOXSMALLGAP)*2
            topB = y * (BOXLENGTH + BOXSMALLGAP) + YMARGIN + BOXBIGGAP*2  + (BOXLENGTH*3+2*BOXSMALLGAP)*2
            return (leftB,topB)
    else:
        return (None,None)    




def getBoxAtPixelA(q, w):
    for boxAx in range(BOARD):
        for boxAy in range(BOARD):
            leftA, topA = leftTopCoordsOfBoxA(boxAx, boxAy)
            boxRect = pygame.Rect(leftA, topA, (BOXLENGTH*3+2*BOXSMALLGAP),(BOXLENGTH*3+2*BOXSMALLGAP))
            if boxRect.collidepoint(q, w):
                return (boxAx,boxAy)
    B=(None,None)
    return B         






def getBoxAtPixelB(e, r):
    for x in range(BOARD):
        for y in range(BOARD):
            leftB, topB = leftTopCoordsOfBoxB(x, y)
            boxRect = pygame.Rect(leftB,topB,BOXLENGTH,BOXLENGTH)
            if boxRect.collidepoint(e, r):
                A=(x,y)
                return A
    B=(None,None)
    return B 




#������ô��ͼ ����
def drawBoxA():#9�������
    for boxAx in range(BOARD):
        for boxAy in range(BOARD):

         leftA, topA = leftTopCoordsOfBoxA(boxAx, boxAy)

         pygame.draw.rect(DISPLAYSURF,YELLOW,leftA , topA,(BOXLENGTH*3+2*BOXSMALLGAP),
                          (BOXLENGTH*3+2*BOXSMALLGAP))


def drawBoxB():#81��С����
    for x in range(BOARD):
        for y in range(BOARD):
            for boxBx in range(BOARD):
                for boxBy in range(BOARD):

                     leftB, topB = leftTopCoordsOfBoxB(boxBx, boxBy)
        
                     pygame.draw.rect(DISPLAYSURF,YELLOW,leftB , topB,BOXSMALLGAP,
                          BOXSMALLGAP)



def darwimag(boxAx, boxAy,boxBx, boxBy):
    i = randint(1,2)   
    if EIGHTYONE[boxAx][boxAy][boxBx][boxBy]=='belongtoA':
        leftB, topB = leftTopCoordsOfBoxB(boxBx, boxBy)
        if i==1:
            DISPLAYSURF.blit(IMAGESDICT['plant1'], (leftB, topB))
        else:
            DISPLAYSURF.blit(IMAGESDICT['plant2'], (leftB, topB))
    elif EIGHTYONE[boxAx][boxAy][boxBx][boxBy]=='belongtoB':
        leftB, topB = leftTopCoordsOfBoxB(boxBx, boxBy)
        if i==1:
            DISPLAYSURF.blit(IMAGESDICT['rubbish1'], (leftB, topB))
        else:
            DISPLAYSURF.blit(IMAGESDICT['rubbish2'], (leftB, topB))





def showresult():
    DISPLAYSURF.blit(IMAGESDICT['huosheng'],(0,0))
    if RESULT == 'Awin':
        textSurf = BASICFONT.render('CONGRATULATIONS! YOU ARE GREENER!', True, GREEN, NAVYBLUE)
        textRect = textSurf.get_rect()
        textRect.center=(400,300)#λ�ô�
        DISPLAYSURF.blit(textSurf,textRect)
        print '1'
    elif RESULT == 'Bwin':
        textSurf = BASICFONT.render('UNFORTUNATELY, the environment is polluted!', True, GREEN, NAVYBLUE)
        textRect = textSurf.get_rect()
        textRect.center=(400,300)#λ�ô�
        DISPLAYSURF.blit(textSurf,textRect)
        print '1'
    elif RESULT == 'DRAW GAME':
        textSurf = BASICFONT.render('Draw Game!', True, GREEN, NAVYBLUE)
        textRect = textSurf.get_rect()
        textRect.center=(400,300)#λ�ô�
        DISPLAYSURF.blit(textSurf,textRect)
        print '1'
    pygame.display.update()
    pygame.time.wait(15000)
    pygame.quit()
    sys.exit()
    


if __name__ == '__main__':
    main()




